# bash-ssh-menu
![](diagram/diag_01.jpg)

## A simple ssh-bash script with menu selection

### What you need to do?
* clone this repo or download `menu.sh` file.
* edit servers list `SERVERS=('server-db1' 'app-server04' 'ansible-server' 'k8s-master' 'mysql-dev-srv02')`
* you can set a default user name under `USERNAME=`

#
Feel free to open issue
<br>
Did you find it useful? I'd love to get a star :star:


###
<a href="https://www.buymeacoffee.com/haim_cohen" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
