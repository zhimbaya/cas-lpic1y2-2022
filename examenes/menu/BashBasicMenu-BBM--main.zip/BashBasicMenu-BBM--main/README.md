# BashBasicMenu-BBM-
Basic Bash Menu for most used Linux Admin Tasks

<h2>Usage:</h2>
$ git clone https://github.com/Poellie01/BashBasicMenu-BBM- <br>
$ cd BashBasicMenu-BBM- <br>
$ chmod +x menu.sh <br>
$ ./menu.sh
