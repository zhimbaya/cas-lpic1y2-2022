# Este repositorio fue realizado utilizando
bash --version # > 4.4
